#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""doctor.py —— HA 驱动全链路体检（在网关上执行）

一次把 6 段链路全部打勾/报警，输出可直接贴给人看的表：

  1 LINK 进程 / 2 驱动进程与心跳 / 3 设备表认领状态(oid src、sid src、online、属性)
  4 HA 可达性与实体存在 / 5 控制端在线(8586 会话) / 6 最近下发与驱动执行结果

用法：python3 doctor.py            # 全量
      python3 doctor.py --quiet    # 只输出失败项
"""
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(BASE, "config", "ha_map.json")
INSTALL = os.path.join(BASE, "install.conf")
DEV_DIR = "/hdlFamily/DIAGW/config/device"
LOG = "/var/log/ha_driver.log"

FAILS = []
WARNS = []


def sh(cmd):
    try:
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        return p.communicate(timeout=15)[0].decode("utf-8", "replace").strip()
    except Exception:
        return ""


def line(ok, tag, detail):
    mark = "PASS" if ok else "FAIL"
    if not ok:
        FAILS.append("%s: %s" % (tag, detail))
    print("  [%s] %-28s %s" % (mark, tag, detail))


def warn(tag, detail):
    WARNS.append(detail)
    print("  [WARN] %-28s %s" % (tag, detail))


def read_install():
    name, code = "HA", ""
    try:
        for raw in open(INSTALL):
            raw = raw.strip()
            if raw.startswith("NAME="):
                name = raw.split("=", 1)[1].strip()
            elif raw.startswith("CODE="):
                code = raw.split("=", 1)[1].strip()
    except OSError:
        pass
    return name, code


def items_of(path):
    if not os.path.exists(path):
        return {}
    obj = json.load(open(path))
    its = obj if isinstance(obj, list) else obj.get("objects") or []
    key = "sid" if "sid" in (its[0] if its else {}) else "oid"
    return {str(x.get(key, "")).upper(): x for x in its}


def ha_states(base, token):
    req = urllib.request.Request(base.rstrip("/") + "/api/states",
                                 headers={"Authorization": "Bearer " + token})
    with urllib.request.urlopen(req, timeout=8) as r:
        return json.loads(r.read().decode())


def main():
    quiet = "--quiet" in sys.argv
    driver, code = read_install()
    t0 = time.time()

    print("=== doctor  %s  CODE=%s  %s" % (driver, code, time.strftime("%Y-%m-%d %H:%M:%S")))

    # 1 LINK
    pid = sh("pidof HDL-LINK")
    line(bool(pid), "LINK 进程", "pid=%s" % (pid or "未运行"))

    # 2 驱动
    drv = sh("pidof -s python3; ps -eo pid,etime,args | grep -a 'HA/ha_driver.py' | grep -v grep")
    drv_line = drv.splitlines()[0].strip() if drv.strip() else ""
    line(bool(drv_line), "驱动进程", drv_line or "未运行（start.sh 会在 3 秒内拉起）")
    hb = sh("grep -a -F 'driver/heartbeat' %s | tail -n 1" % LOG)
    fresh = False
    if hb:
        try:
            ts = time.mktime(time.strptime(hb[:19], "%Y-%m-%d %H:%M:%S"))
            fresh = (t0 - ts) < 40
        except Exception:
            fresh = False
    line(fresh, "驱动心跳", (hb[-40:] if hb else "无心跳记录"))

    if not os.path.exists(CONF):
        line(False, "映射表", "缺少 %s" % CONF)
        return summary()
    conf = json.load(open(CONF))
    devs = conf.get("devices") or []
    line(bool(devs), "映射表", "%d 台设备" % len(devs))

    sid_items = items_of(os.path.join(DEV_DIR, "device_sid.json"))
    oid_items = items_of(os.path.join(DEV_DIR, "device_oid.json"))

    bad = []
    try:
        from provision import need_keys
    except Exception:
        def need_keys(d):
            return ["on_off"] + (["position"] if (d.get("entity") or "").startswith("cover.") else [])
    for d in devs:
        sid = str(d.get("sid", "")).upper()
        oid = str(d.get("oid") or sid[:16]).upper()
        o = oid_items.get(oid)
        s = sid_items.get(sid)
        if not o:
            bad.append("%s 无 oid 记录" % oid)
            continue
        if str(o.get("src", "")).upper() != driver.upper():
            bad.append("%s src=%r" % (oid, o.get("src")))
        if code and str(o.get("driver_code", "")).upper() != code.upper():
            bad.append("%s code=%r" % (oid, o.get("driver_code")))
        if not s:
            bad.append("%s 无 sid 记录" % sid)
            continue
        if str(s.get("online", "")).lower() != "true":
            bad.append("%s 不在线" % sid)
        have = {a.get("key") for a in (s.get("attributes") or [])}
        miss = set(need_keys(d)) - have
        if miss:
            bad.append("%s 缺属性 %s" % (sid, ",".join(sorted(miss))))
    line(not bad, "设备认领(表)", "全部就绪" if not bad else "; ".join(bad[:6]) +
         ("" if len(bad) <= 6 else " 等 %d 项" % len(bad)))

    # 4 HA 可达
    ha = conf.get("ha") or {}
    base = (ha.get("base_url") or ha.get("base") or "").rstrip("/")
    token = ha.get("token") or ""
    if not base or not token:
        line(False, "HA 配置", "ha_map.json 缺少 base_url / token")
    else:
        try:
            t1 = time.time()
            st = ha_states(base, token)
            ms = int((time.time() - t1) * 1000)
            known = {x.get("entity_id") for x in st}
            missing = [d["entity"] for d in devs if d.get("entity") not in known]
            line(not missing, "HA 可达 + 实体", "%s  %dms  实体 %d/%d" %
                 (base, ms, len(devs) - len(missing), len(devs)) if missing
                 else "%s  %dms  实体齐" % (base, ms))
            if missing:
                warn("实体缺失", ", ".join(missing[:5]))
        except Exception as err:
            line(False, "HA 可达", "%s -> %s" % (base, err))

    # 5 控制端在线
    est = sh("netstat -an 2>/dev/null | grep -a ':8586' | grep -a ESTABLISHED | wc -l")
    try:
        n = int(est or 0)
    except ValueError:
        n = 0
    line(n > 0, "控制端在线(8586)", "%d 条会话" % n +
         ("" if n else "   ← Studio/App 没连上网关，点\"测试\"不会下发"))

    # 6 最近下发
    recent = sh("awk -v d=\"$(date -d '-30 min' '+%%Y-%%m-%%d %%H:%%M:%%S')\" "
                "'$0>=d' %s | grep -a -F '[down]' | wc -l" % LOG)
    total = sh("grep -a -c -F '[down]' %s" % LOG)
    try:
        rc = int(recent or 0)
    except ValueError:
        rc = 0
    last = sh("grep -a -F '[down]' %s | tail -n 1" % LOG)
    if rc:
        line(True, "近 30 分钟下发", "%d 次 | 累计 %s | 最后 %s" % (rc, total, last[-70:]))
    else:
        warn("近 30 分钟下发", "0 次（累计 %s）——若此刻正在点击，先看\"控制端在线\"" % total)

    print("\n耗时 %.1fs" % (time.time() - t0))
    return summary()


def summary():
    if FAILS:
        print("\nRESULT: FAIL  %d 项" % len(FAILS))
        tips = {
            "505002": "设备不在线 → provision.py --apply --reload",
            "500001": "属性键/类型不匹配 → 校正 attributes",
            "500002": "驱动 CODE 不匹配 → 核对 install.conf CODE",
            "8586": "控制端未连接 → 在 Studio 里点「读取」重连",
        }
        for f in FAILS:
            print("  - " + f)
        for k, v in tips.items():
            if any(k in f for f in FAILS):
                print("    建议: %s" % v)
        return 1
    if WARNS:
        print("\nRESULT: PASS (含 %d 条提醒)" % len(WARNS))
    else:
        print("\nRESULT: PASS  链路健康")
    return 0


if __name__ == "__main__":
    sys.exit(main())
