#!/bin/sh
DIR=$(cd "$(dirname "$0")" && pwd)
pkill -f "$DIR/ha_driver.py" 2>/dev/null
rm -f /hdlFamily/DIAGW/config/driver/HA/launch.json
echo "$(date '+%Y-%m-%d %H:%M:%S') [uninstall.sh] HA 驱动已卸载" >> /var/log/ha_driver.log
