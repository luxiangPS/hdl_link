#!/bin/sh
# 只停本驱动：先停 start.sh 守护循环，再停 ha_driver.py
DIR=$(cd "$(dirname "$0")" && pwd)
pkill -f "$DIR/start.sh" 2>/dev/null
sleep 1
pkill -f "$DIR/ha_driver.py" 2>/dev/null
echo "$(date '+%Y-%m-%d %H:%M:%S') [stop.sh] HA 驱动已停止" >> /var/log/ha_driver.log
