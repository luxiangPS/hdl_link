#!/bin/sh
# 本地文件安装 / 升级（HA 驱动）
#
# 用法（在网关上执行，不需要任何账号密码、不联网）：
#   sh /tmp/ha-driver/install.sh              # 首次安装或原地升级，自动重启驱动
#   sh /tmp/ha-driver/install.sh --no-restart # 只落文件，不重启
#
# 升级语义（重要）：目标目录已存在时，config/ha_map.json 与 config/device_sn.json
# 一律保留现场版本，只做备份，绝不覆盖；否则包内空令牌会把现场映射冲掉。

DIR=$(cd "$(dirname "$0")" && pwd)
NAME=$(grep -m1 '^NAME=' "$DIR/install.conf" | cut -d= -f2 | tr -d ' \r')
[ -z "$NAME" ] && NAME=HA
TARGET=/hdlFamily/ipc/driver/$NAME
TS=$(date '+%Y%m%d%H%M%S')
RESTART=1
[ "$1" = "--no-restart" ] && RESTART=0

mkdir -p "$TARGET/config" "/hdlFamily/DIAGW/config/driver/$NAME"

echo "[install] $NAME -> $TARGET  (源: $DIR)"

# 1) 程序与脚本
if [ "$DIR" != "$TARGET" ]; then
    cp -f "$DIR/ha_driver.py" "$DIR/install.conf" "$DIR/start.sh" "$DIR/stop.sh" \
          "$DIR/uninstall.sh" "$TARGET/" 2>/dev/null
    chmod 755 "$TARGET/ha_driver.py" "$TARGET/start.sh" "$TARGET/stop.sh" \
              "$TARGET/uninstall.sh" 2>/dev/null

    for f in ha_map.json device_sn.json; do
        SRC="$DIR/config/$f"
        DST="$TARGET/config/$f"
        if [ -f "$DST" ]; then
            # 升级：现场配置优先，只备份，不覆盖
            if [ -f "$SRC" ] && ! cmp -s "$SRC" "$DST"; then
                cp -f "$DST" "$DST.bak-$TS" 2>/dev/null
                echo "[install] 保留现场 config/$f（备份 -> config/$f.bak-$TS）"
            fi
        elif [ -f "$SRC" ]; then
            cp -f "$SRC" "$DST"
            echo "[install] 首次安装，写入 config/$f"
        fi
    done
fi

# 2) LINK 拉起配置
cat > "/hdlFamily/DIAGW/config/driver/$NAME/launch.json" <<'EOF'
{"enable":true,"start":true,"startDelay":2,"stopDelay":1}
EOF

# 3) 不回检名单
grep -qx "$NAME" /hdlFamily/DIAGW/.licnocheck.conf 2>/dev/null || echo "$NAME" >> /hdlFamily/DIAGW/.licnocheck.conf

# 4) 重启驱动（只重启驱动本身，不动 LINK、不踢 Studio 会话）
if [ "$RESTART" = "1" ]; then
    pkill -f "$TARGET/start.sh" 2>/dev/null
    for p in $(ps -eo pid,args 2>/dev/null | grep -a "$TARGET/ha_driver.py" | grep -v grep | awk '{print $1}'); do
        kill -9 "$p" 2>/dev/null
    done
    sleep 3
    nohup "$TARGET/start.sh" >/dev/null 2>&1 &
    sleep 3
fi

VER=$(grep -m1 '^VERSION=' "$TARGET/install.conf" | cut -d= -f2 | tr -d ' \r')
CODE=$(grep -m1 '^CODE=' "$TARGET/install.conf" | cut -d= -f2 | tr -d ' \r')
IMG=$(grep -m1 '^IMAGEID=' "$TARGET/install.conf" | cut -d= -f2 | tr -d ' \r')
echo "[install] installed $NAME  version=$VER  module=$(echo "$CODE" | tr 'A-Z' 'a-z')#$IMG"
echo "$(date '+%Y-%m-%d %H:%M:%S') [install.sh] $NAME $VER installed at $TARGET" >> /var/log/ha_driver.log
