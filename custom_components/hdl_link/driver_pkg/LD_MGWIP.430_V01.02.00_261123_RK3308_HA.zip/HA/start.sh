#!/bin/sh
# HA 驱动启动脚本：保证 ha_driver.py 常驻，异常退出 3 秒后重拉
DIR=$(cd "$(dirname "$0")" && pwd)
LOG=/var/log/ha_driver.log
mkdir -p "$DIR/config"
echo "$(date '+%Y-%m-%d %H:%M:%S') [start.sh] 启动 HA 驱动 ($DIR)" >> $LOG

while true; do
    if ! pgrep -f "$DIR/ha_driver.py" > /dev/null 2>&1; then
        python3 "$DIR/ha_driver.py" > /dev/null 2>&1 &
    fi
    sleep 3
done
