#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""provision.py —— HDL 网关侧「驱动设备认领 / 自愈」工具（HA 驱动专用）

作用：把 config/ha_map.json 里声明的每一台设备，在 LINK 的两张设备表里补齐到
「能被驱动接管」的状态。只有这三件事同时成立，LINK 才肯把 property/down 转给驱动：

  1) device_oid.json : 该 oid 的 src == 驱动名(HA)、driver_code == install.conf 的 CODE
  2) device_sid.json : 该 sid 的 src == HA、online == "true"
  3) device_sid.json : 属性键与类型要能被 LINK 校验通过（否则 500001 status内容错误）
     - on_off    string
     - brightness / percent / position   integer 0-100

用法（在网关上执行）：
  python3 provision.py            # 只体检，不改文件（默认）
  python3 provision.py --apply    # 实际写入，自动备份 *.bak-YYYYmmddHHMMSS
  python3 provision.py --apply --reload   # 写入后重启 LINK 让 online 标记生效
                                          # 注意：重启会断开 Studio 会话，需重新「读取」

为什么必须改文件：LINK 的 device/edit、function/attribute/edit 能改 src/属性，
但改不了 device_sid.json 里的 online 标记，而 online 才是 505002 的开关。
online 只在 LINK 载入配置时读取，所以写完要 --reload 一次。
"""
import argparse
import json
import os
import shutil
import sys
import time

BASE = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(BASE, "config", "ha_map.json")
INSTALL = os.path.join(BASE, "install.conf")
DEV_DIR = "/hdlFamily/DIAGW/config/device"
SID_FILE = os.path.join(DEV_DIR, "device_sid.json")
OID_FILE = os.path.join(DEV_DIR, "device_oid.json")


def read_install():
    name, code = "HA", "00898978"
    try:
        for line in open(INSTALL):
            line = line.strip()
            if line.startswith("NAME="):
                name = line.split("=", 1)[1].strip()
            elif line.startswith("CODE="):
                code = line.split("=", 1)[1].strip()
    except OSError:
        pass
    return name, code


def load_json(path):
    with open(path) as f:
        obj = json.load(f)
    return obj


def items_of(obj):
    if isinstance(obj, list):
        return obj
    return obj.get("objects") or []


def domain_of(dev):
    d = dev.get("domain")
    if d:
        return d
    return (dev.get("entity") or "").split(".")[0]


def need_keys(dev):
    """这台设备在 LINK 侧必须有的属性键（缺了就会出现 500001 或控件点不动）"""
    dom = domain_of(dev)
    keys = ["on_off"]
    if dom == "cover":
        keys.append("position")
    elif "brightness" in (dev.get("attrs") or []):
        keys.append("brightness")
    return keys


def attr_def(key, domain):
    if key == "on_off":
        values = ["on", "off", "stop"] if domain == "cover" else ["on", "off"]
        return {"key": "on_off", "data_type": "string", "value": values}
    if key == "percent":
        # 历史遗留键：虚拟窗帘卡上叫 percent，语义与 position 相同，原样保留不删列
        return {"key": "percent", "data_type": "integer", "max": 100, "min": 0, "value": []}
    return {"key": key, "data_type": "integer", "max": 100, "min": 0, "value": []}


def merged_attrs(sid_rec, dev):
    """在现有属性基础上补齐必需键：不删列（避免 Studio 端已缓存的字段消失），只加缺的"""
    cur = [a.get("key") for a in (sid_rec.get("attributes") or []) if a.get("key")]
    if not cur:
        cur = list(dev.get("attrs") or ["on_off"])
    want = list(cur)
    for k in need_keys(dev):
        if k not in want:
            want.append(k)
    dom = domain_of(dev)
    return [attr_def(k, dom) for k in want]


def stamp():
    return time.strftime("%Y%m%d%H%M%S")


def backup(path):
    if os.path.exists(path):
        dst = "%s.bak-%s" % (path, stamp())
        shutil.copyfile(path, dst)
        return dst
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="实际写入（默认只体检）")
    ap.add_argument("--reload", action="store_true", help="写入后重启 LINK 让 online 生效")
    ap.add_argument("--map", default=CONF)
    args = ap.parse_args()

    driver, code = read_install()
    if not os.path.exists(args.map):
        print("FAIL 找不到映射表 %s" % args.map)
        return 2
    conf = load_json(args.map)
    devs = conf.get("devices") or []
    if not devs:
        print("FAIL 映射表里没有 devices")
        return 2
    if not (os.path.exists(SID_FILE) and os.path.exists(OID_FILE)):
        print("FAIL 找不到 LINK 设备表，路径 %s" % DEV_DIR)
        return 2

    sid_obj = load_json(SID_FILE)
    oid_obj = load_json(OID_FILE)
    sid_items = items_of(sid_obj)
    oid_items = items_of(oid_obj)
    sid_map = {str(x.get("sid", "")).upper(): x for x in sid_items}
    oid_map = {str(x.get("oid", "")).upper(): x for x in oid_items}

    changes = []
    problems = []
    for dev in devs:
        sid = str(dev.get("sid", "")).upper()
        oid = str(dev.get("oid") or sid[:16]).upper()
        name = dev.get("name") or oid
        domain = domain_of(dev)
        attrs = dev.get("attrs") or ["on_off"]

        # ---- device_oid.json ----
        o = oid_map.get(oid)
        if not o:
            problems.append("%s 缺 oid 记录（设备没在 LINK 设备表里）" % oid)
            new_o = {"oid": oid, "device_name": name,
                     "device_mac": str(dev.get("mac") or oid[:12]).upper(),
                     "device_model": "HA.device", "addresses": "0E01",
                     "driver_code": code, "hw_version": "1.0", "fw_version": "1.0.0",
                     "src": driver, "from": (conf.get("ha") or {}).get("user_oid", ""),
                     "image_info": []}
            oid_items.append(new_o)
            oid_map[oid] = new_o
            changes.append("%s oid 新建" % oid)
        else:
            if str(o.get("src", "")).upper() != driver.upper():
                changes.append("%s src %r → %s" % (oid, o.get("src"), driver))
                o["src"] = driver
            if str(o.get("driver_code", "")).upper() != code.upper():
                changes.append("%s driver_code %r → %s" % (oid, o.get("driver_code"), code))
                o["driver_code"] = code
            if not o.get("device_model"):
                o["device_model"] = "HA.device"

        # ---- device_sid.json ----
        s = sid_map.get(sid)
        if not s:
            problems.append("%s 缺 sid 记录（Studio 里加过设备但 LINK 没建档）" % sid)
            continue
        if str(s.get("src", "")).upper() != driver.upper():
            changes.append("%s sid src %r → %s" % (sid, s.get("src"), driver))
            s["src"] = driver
        if str(s.get("online", "")).lower() != "true":
            changes.append("%s online %r → true" % (sid, s.get("online")))
            s["online"] = "true"
        if s.get("attributes") != merged_attrs(s, dev):
            changes.append("%s 属性定义校正 (%s)" % (sid, ",".join(attrs)))
            s["attributes"] = merged_attrs(s, dev)
        if not s.get("spk"):
            s["spk"] = dev.get("spk") or "light.switch"

    print("=== provision  %s  CODE=%s  devices=%d" % (driver, code, len(devs)))
    if problems:
        print("\n[阻塞项]")
        for p in problems:
            print("  ! " + p)
    print("\n[变更]  %d 项" % len(changes))
    for c in changes[:60]:
        print("  - " + c)
    if len(changes) > 60:
        print("  ... 其余 %d 项省略" % (len(changes) - 60))

    if not changes:
        print("\nRESULT: PASS  已在位，无需改动")
        return 0
    if not args.apply:
        print("\nRESULT: 待写入（加 --apply 生效）")
        return 0

    b1 = backup(SID_FILE)
    b2 = backup(OID_FILE)
    tmp = SID_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(sid_obj, f, ensure_ascii=False)
    shutil.move(tmp, SID_FILE)
    tmp = OID_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(oid_obj, f, ensure_ascii=False)
    shutil.move(tmp, OID_FILE)
    print("\n[写入] 完成  备份: %s / %s" % (os.path.basename(b1 or "-"), os.path.basename(b2 or "-")))

    if args.reload:
        print("[reload] 重启 LINK ...")
        os.system("kill -9 $(pidof HDL-LINK) 2>/dev/null")
        for _ in range(30):
            time.sleep(1)
            if os.popen("pidof HDL-LINK").read().strip():
                break
        time.sleep(5)
        print("[reload] LINK pid=%s，驱动会在 3 秒内被 start.sh 拉起" %
              os.popen("pidof HDL-LINK").read().strip())
        print("[reload] 提醒：Studio 会话已断开，需在 Studio 里重新「读取」")
    else:
        print("\n提示：online 标记只在 LINK 载入配置时生效，请加 --reload 执行一次")
    print("\nRESULT: APPLIED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
