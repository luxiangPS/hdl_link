#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""verify_live.py —— 端到端验收（在网关上执行）

对 ha_map 里每一台设备，先读它在 HA 的真实状态，再把"与当前状态完全一致"的指令
下发一遍（幂等：灯已开就下发"开+当前亮度"，窗帘已开就下发"open+当前位置"）。

因此它既不会改变现场，又能同时证明三件事：
  1 LINK 把 down 路由到了驱动（否则 505001/505002）
  2 驱动的属性键被 LINK 校验通过（否则 500001）
  3 驱动到 HA 的 REST 调用成功（日志里 200）

用法：python3 verify_live.py            # 全部设备
      python3 verify_live.py --only cover   # 只验窗帘
"""
import json
import os
import socket
import sys
import time
import urllib.error
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(BASE, "config", "ha_map.json")
UDS = "/hdlFamily/ipc/path/uds-ipc"
LOG = "/var/log/ha_driver.log"


def ha(conf, path):
    h = conf.get("ha") or {}
    base = (h.get("base_url") or h.get("base") or "").rstrip("/")
    req = urllib.request.Request(base + path,
                                 headers={"Authorization": "Bearer " + h.get("token", "")})
    with urllib.request.urlopen(req, timeout=8) as r:
        return json.loads(r.read().decode())


def call(topic, body, wait=3.0):
    body.setdefault("id", "v%d" % (int(time.time() * 1000) % 100000))
    body.setdefault("time_stamp", str(int(time.time() * 1000)))
    raw = json.dumps(body, ensure_ascii=False)
    frame = ("Topic:%s\r\nLength:%d\r\n\r\n%s" % (topic, len(raw.encode()), raw)).encode()
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(wait)
    s.connect(UDS)
    s.sendall(frame)
    buf = b""
    deadline = time.time() + wait
    while time.time() < deadline:
        try:
            c = s.recv(65536)
            if not c:
                break
            buf += c
        except socket.timeout:
            break
    s.close()
    text = buf.decode("utf-8", "ignore")
    i = text.find("\r\n\r\n")
    return text[i + 4:] if i > 0 else text


def down(dst, keys):
    """dst=驱动已握手的 topic，直接把下行帧送到驱动侧，模拟 LINK 转发"""
    return call("/base/ipc/thing/property/down",
                {"objects": [{"sid": dst, "status": keys}]})


def want_status(dev, st):
    """按 HA 当前状态造一条等价指令"""
    dom = dev.get("domain") or (dev.get("entity") or "").split(".")[0]
    attrs = st.get("attributes") or {}
    keys = []
    state = (st.get("state") or "").lower()
    if dom == "cover":
        pos = attrs.get("current_position")
        if pos is not None:
            keys.append({"key": "position", "value": str(int(pos))})
        keys.insert(0, {"key": "on_off", "value": "open" if state in ("open", "opening") else "close"})
    else:
        keys.append({"key": "on_off", "value": "on" if state in ("on", "open") else "off"})
        if attrs.get("brightness") is not None:
            keys.append({"key": "brightness", "value": str(int(round(attrs["brightness"] * 100 / 255)))})
    return keys


def main():
    only = None
    if "--only" in sys.argv:
        only = sys.argv[sys.argv.index("--only") + 1]
    conf = json.load(open(CONF))
    devs = [d for d in (conf.get("devices") or [])
            if not only or only in (d.get("domain") or d.get("entity", ""))]
    ok = fail = 0
    print("=== verify_live  %d 台  %s" % (len(devs), time.strftime("%H:%M:%S")))
    for d in devs:
        sid = d["sid"]
        try:
            st = ha(conf, "/api/states/%s" % d["entity"])
        except Exception as err:
            print("  [FAIL] %-22s 读 HA 状态失败 %s" % (d.get("name"), err))
            fail += 1
            continue
        keys = want_status(d, st)
        raw = down(sid, keys)
        good = '"code":"0"' in raw or '"code": "0"' in raw or "Success" in raw
        desc = " ".join("%s=%s" % (k["key"], k["value"]) for k in keys)
        print("  [%s] %-22s %-28s %s" % ("PASS" if good else "FAIL", d.get("name"), desc,
                                          "" if good else raw[:120]))
        ok += good
        fail += (not good)
        time.sleep(0.4)
    print("\nRESULT: %d PASS / %d FAIL" % (ok, fail))
    tail = os.popen("grep -a -F '[down]' %s | tail -n %d" % (LOG, max(len(devs), 5))).read()
    if tail.strip():
        print("\n驱动侧执行记录：")
        for ln in tail.strip().splitlines()[-len(devs):]:
            print("  " + ln[:150])
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
