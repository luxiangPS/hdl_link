#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""名字 → LINK 驱动 CODE 计算器

复刻 HDL-LINK 里的 DriverManager_MakeDriverCode（aarch64 反汇编还原）。
LINK 握手时会用同样的算法算一遍，跟驱动上报的 code 比字符串，不等就回
500002 DriverCode不匹配。

用法：
    python code_of_name.py HA          → 00898978
    python code_of_name.py --check     → 用真机已知 CODE 自检
"""
import sys

DIGITS = "0123456789ABCDEF"

KNOWN = {
    "HA": "00898978",     # 本驱动
    "RDBG": "011F1E09",   # 网关自带的 frp 包
    "buspro": "029B9988",
    "HomeKit": "02B1B372",
    "485test": "02616322",
}


def code_of_name(name: str) -> str:
    s = sum(ord(c) for c in name)
    b1 = ((s >> 8) & 0xFF) ^ (s & 0xFF)
    b2 = (((0x55 ^ ((s >> 8) & 0xFF)) & 0xFF) + ((0xAA ^ (s & 0xFF)) & 0xFF)) & 0xFF
    return "".join([
        DIGITS[(s >> 12) & 0xF], DIGITS[(s >> 8) & 0xF],
        DIGITS[(s >> 4) & 0xF], DIGITS[s & 0xF],
        DIGITS[(b1 >> 4) & 0xF], DIGITS[b1 & 0xF],
        DIGITS[(b2 >> 4) & 0xF], DIGITS[b2 & 0xF],
    ])


def self_check() -> bool:
    ok = True
    for name, expect in KNOWN.items():
        got = code_of_name(name)
        flag = "OK" if got == expect else "MISMATCH"
        print("%-9s expect=%s got=%s %s" % (name, expect, got, flag))
        ok = ok and got == expect
    return ok


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        sys.exit(0 if self_check() else 1)
    names = sys.argv[1:] or ["HA"]
    for n in names:
        print("%s -> %s" % (n, code_of_name(n)))
