#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HA 驱动（网关侧）

链路：HDL App / 面板 → LINK → 本驱动(UDS) → Home Assistant REST API → HA 实体
回传：HA 状态 → 本驱动 → LINK property/up → App 显示

网关内部驱动标识固定为 HA，CODE=00898978（由 MakeDriverCode("HA") 算得，
LINK 握手时用它做比对，见 code_of_name.py）。

配置：<驱动目录>/config/ha_map.json
{
  "ha": {"base_url": "http://<ha-host>:8123", "token": "<long-lived-token>", "gw_id": "<网关id>"},
  "devices": [
    {"sid": "0A2C...010101", "oid": "0A2C...", "entity": "light.ceiling",
     "domain": "light", "spk": "light.switch", "attrs": ["on_off"], "name": "客厅灯"}
  ]
}
"""
import json
import os
import socket
import threading
import time
import urllib.error
import urllib.request

UDS = "/hdlFamily/ipc/path/uds-ipc"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONF = os.path.join(BASE_DIR, "config", "ha_map.json")


def read_identity():
    """驱动名 / CODE 以同目录 install.conf 为准，改配置即可切换，不用改代码。

    NAME / CODE      : 对外的驱动名（目录名、Studio 显示名、设备 src）
    IPC_NAME / IPC_CODE : 握手时实际发送给 LINK 的名字与 CODE（可选）。
                         固件白名单只认有限几个名字，可在此临时借用，对用户不可见。
    """
    name, code = "HA", "0A11A0AA"
    ipc_name = ipc_code = None
    try:
        with open(os.path.join(BASE_DIR, "install.conf")) as f:
            for line in f:
                line = line.strip()
                if line.startswith("NAME="):
                    name = line.split("=", 1)[1].strip()
                elif line.startswith("CODE="):
                    code = line.split("=", 1)[1].strip()
                elif line.startswith("IPC_NAME="):
                    ipc_name = line.split("=", 1)[1].strip()
                elif line.startswith("IPC_CODE="):
                    ipc_code = line.split("=", 1)[1].strip()
    except OSError:
        pass
    return name, code, (ipc_name or name), (ipc_code or code)


DRIVER_NAME, DRIVER_CODE, IPC_NAME, IPC_CODE = read_identity()


def read_version():
    try:
        for line in open(os.path.join(BASE_DIR, "install.conf")):
            if line.strip().startswith("VERSION="):
                return line.split("=", 1)[1].strip()
    except OSError:
        pass
    return "unknown"


VERSION = read_version()
LOG = "/var/log/ha_driver.log"
POLL_INTERVAL = 3

_lock = threading.Lock()
_sock = None
_conf_cache = {"mtime": 0, "data": {}}


def log(msg):
    line = "%s %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with open(LOG, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def encode(topic, body):
    if not isinstance(body, str):
        body = json.dumps(body, ensure_ascii=False, separators=(",", ":"))
    return ("Topic:%s\r\nLength:%d\r\n\r\n%s" % (topic, len(body), body)).encode("utf-8")


def split_frames(buf):
    frames = []
    while b"\r\n\r\n" in buf:
        head, rest = buf.split(b"\r\n\r\n", 1)
        topic = length = None
        for line in head.decode("utf-8", "replace").split("\r\n"):
            if line.startswith("Topic:"):
                topic = line[6:]
            elif line.startswith("Length:"):
                try:
                    length = int(line[7:])
                except ValueError:
                    length = None
        if length is None or len(rest) < length:
            return frames, buf
        frames.append((topic, rest[:length].decode("utf-8", "replace")))
        buf = rest[length:]
    return frames, buf


def send(topic, body):
    with _lock:
        if _sock is None:
            raise RuntimeError("socket closed")
        _sock.sendall(encode(topic, body))
    log("[tx] %s %s" % (topic, json.dumps(body, ensure_ascii=False)[:200]))


def load_conf():
    try:
        mtime = os.path.getmtime(CONF)
        if mtime != _conf_cache["mtime"]:
            with open(CONF) as f:
                _conf_cache["data"] = json.load(f)
            _conf_cache["mtime"] = mtime
            log("[conf] 已加载 %d 个设备映射" % len(_conf_cache["data"].get("devices") or []))
        return _conf_cache["data"]
    except (OSError, ValueError) as err:
        log("[conf] 读取失败 %s: %s" % (CONF, err))
        return _conf_cache["data"] or {}


def ha_base(conf):
    ha = conf.get("ha") or {}
    return (ha.get("base_url") or ha.get("base") or "").rstrip("/")


def ha_request(conf, path, payload=None):
    ha = conf.get("ha") or {}
    base = ha_base(conf)
    if not base:
        return "no base_url", None
    url = base + path
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST" if data else "GET")
    # 令牌优先读配置；配置留空时回落到环境变量，避免把长期令牌写进任何代码/包
    token = ha.get("token") or os.environ.get("HDL_HA_TOKEN", "")
    req.add_header("Authorization", "Bearer %s" % token)
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=6) as resp:
            body = resp.read()
            return resp.status, json.loads(body) if body.strip().startswith(b"[") or body.strip().startswith(b"{") else None
    except urllib.error.HTTPError as err:
        return err.code, None
    except Exception as err:  # noqa: BLE001
        return "ERR %s" % err, None


def call_service(conf, domain, service, data):
    code, _ = ha_request(conf, "/api/services/%s/%s" % (domain, service), data)
    return code


def value_to_bool(value):
    return str(value).strip().lower() in ("on", "true", "1", "open")


def handle_down(conf, body):
    try:
        payload = json.loads(body)
    except ValueError:
        log("[down] 非 JSON：%s" % body[:200])
        return
    devs = {str(d.get("sid", "")).upper(): d for d in conf.get("devices") or []}
    acked = []
    for obj in payload.get("objects") or []:
        sid = str(obj.get("sid", "")).upper()
        dev = devs.get(sid)
        if not dev:
            log("[down] 未映射 sid %s" % sid)
            continue
        acked.append(sid)
        entity = dev["entity"]
        domain = dev.get("domain") or "homeassistant"
        for st in obj.get("status") or []:
            key, value = st.get("key"), st.get("value")
            if key == "on_off":
                if entity.startswith("cover."):
                    # 窗帘没有 turn_on/turn_off，必须走 open/close/stop_cover
                    v = str(value).strip().lower()
                    if v in ("open", "on", "true", "1"):
                        service = "open_cover"
                    elif v in ("close", "off", "false", "0"):
                        service = "close_cover"
                    else:
                        service = "stop_cover"
                    domain = "cover"
                else:
                    service = "turn_on" if value_to_bool(value) else "turn_off"
                log("[down] %s on_off=%s → %s.%s(%s) → %s"
                    % (sid, value, domain, service, entity, call_service(conf, domain, service, {"entity_id": entity})))
            elif key in ("brightness", "percent", "position", "curtain"):
                # Studio 里窗帘用的是 percent，驱动统一按实体域分流：
                # cover.* 走位置，其余走亮度
                try:
                    val = max(0, min(100, int(float(value))))
                except (TypeError, ValueError):
                    continue
                if entity.startswith("cover."):
                    log("[down] %s %s=%s → cover.set_cover_position(%s) → %s"
                        % (sid, key, val, entity,
                           call_service(conf, "cover", "set_cover_position",
                                        {"entity_id": entity, "position": val})))
                else:
                    pct = max(1, val)
                    log("[down] %s %s=%s → light.turn_on(%s) → %s"
                        % (sid, key, pct, entity,
                           call_service(conf, "light", "turn_on",
                                        {"entity_id": entity, "brightness_pct": pct})))
            else:
                log("[down] %s 未处理属性 %s=%s" % (sid, key, value))
    if acked:
        try:
            send("/base/ipc/thing/property/down_reply",
                 {"id": payload.get("id", ""), "time_stamp": payload.get("time_stamp", ""),
                  "objects": [{"sid": s, "tag": "Success"} for s in acked],
                  "code": "0", "msg": "Success"})
        except Exception as err:  # noqa: BLE001
            log("[down] ack 失败 %s" % err)


def state_payload(dev, state):
    status = []
    for key in dev.get("attrs") or ["on_off"]:
        if key == "on_off":
            on = state.get("state") in ("on", "open", "opening", "home")
            status.append({"key": "on_off", "value": "on" if on else "off"})
        elif key == "brightness":
            attrs = state.get("attributes") or {}
            b = attrs.get("brightness")
            if b is not None:
                status.append({"key": "brightness", "value": str(int(round(b * 100 / 255)))})
            elif attrs.get("brightness_pct") is not None:
                status.append({"key": "brightness", "value": str(int(attrs["brightness_pct"]))})
        elif key == "position":
            attrs = state.get("attributes") or {}
            if attrs.get("current_position") is not None:
                status.append({"key": "position", "value": str(int(attrs["current_position"]))})
    return status


def up_topic(conf):
    gw = (conf.get("ha") or {}).get("gw_id") or "gw_id"
    return "/base/%s/thing/property/up" % gw


_last = {}


def poll_once(conf):
    base = ha_base(conf)
    if not base or not conf.get("devices"):
        return
    for dev in conf.get("devices") or []:
        code, state = ha_request(conf, "/api/states/%s" % dev["entity"])
        if code != 200 or not isinstance(state, dict):
            log("[poll] %s 取状态失败 %s" % (dev["entity"], code))
            continue
        status = state_payload(dev, state)
        sid = dev.get("sid")
        if status and _last.get(sid) != status:
            _last[sid] = status
            send(up_topic(conf), {"objects": [{"sid": sid, "status": status}],
                                  "id": str(int(time.time() * 1000) % 1000000),
                                  "time_stamp": str(int(time.time() * 1000))})


ATTR_TYPES = {
    "on_off": {"data_type": "string", "value": ["on", "off", "stop"]},
    "brightness": {"data_type": "integer", "max": 100, "min": 0, "value": []},
    "percent": {"data_type": "integer", "max": 100, "min": 0, "value": []},
    "position": {"data_type": "integer", "max": 100, "min": 0, "value": []},
}


def upload_devices(conf):
    """把本驱动的虚拟设备清单上报给 LINK（等价 buspro 的 device/list/upload）。

    LINK 收到后才会把设备的 src 写成驱动名，property/down 才会路由过来。
    """
    objs = []
    if os.path.exists(os.path.join(BASE_DIR, "config", ".no_upload")):
        log("[dev] 已存在 .no_upload，跳过上报")
        return
    for dev in conf.get("devices") or []:
        sid = str(dev.get("sid", "")).upper()
        oid = str(dev.get("oid") or sid[:16]).upper()
        attrs = []
        for key in dev.get("attrs") or ["on_off"]:
            item = dict(ATTR_TYPES.get(key) or ATTR_TYPES["on_off"])
            item["key"] = key
            attrs.append(item)
        objs.append({
            "oid": oid, "sid": sid, "device_name": dev.get("name") or oid,
            "device_mac": str(dev.get("mac") or oid[:12]).upper(),
            "device_model": "RDBG.ha",
            "driver_code": IPC_CODE, "addresses": "0E01",
            "hw_version": "1.0", "fw_version": "1.0.0",
            "spk": dev.get("spk") or "light.switch",
            "omodel": dev.get("spk") or "light.switch",
            "status": "online", "can_group": "false",
            "attributes": attrs,
        })
    if not objs:
        return
    try:
        send("/user/ipc/custom/device/list/upload",
             {"id": str(int(time.time() * 1000) % 1000000),
              "time_stamp": str(int(time.time() * 1000)),
              "objects": objs})
        log("[dev] 已上报 %d 台虚拟设备" % len(objs))
    except Exception as err:  # noqa: BLE001
        log("[dev] 上报失败 %s" % err)


def poller():
    while True:
        try:
            conf = load_conf()
            poll_once(conf)
        except Exception as err:  # noqa: BLE001
            log("[poll] 异常 %s" % err)
        time.sleep(POLL_INTERVAL)


def main():
    global _sock, _last
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(UDS)
    with _lock:
        _sock = s
    log("[conn] 已连接 uds-ipc driver=%s" % DRIVER_NAME)
    send("/user/ipc/custom/driver/connect",
         {"id": str(int(time.time() * 1000) % 1000000),
          "time_stamp": str(int(time.time() * 1000)),
          "driver": IPC_NAME, "code": IPC_CODE})

    conf = load_conf()
    if conf:
        log("[boot] %s  driver=%s code=%s  devices=%d  ha=%s" %
            (VERSION, DRIVER_NAME, DRIVER_CODE, len(conf.get("devices") or []), ha_base(conf)))
        upload_devices(conf)
        _last = {}
        poll_once(conf)  # 连上先推一次真实状态
    threading.Thread(target=poller, daemon=True).start()

    s.settimeout(1.0)
    buf = b""
    while True:
        try:
            chunk = s.recv(65536)
        except socket.timeout:
            continue
        except OSError as err:
            log("[conn] recv 失败 %s" % err)
            break
        if not chunk:
            log("[conn] LINK 断开")
            break
        buf += chunk
        frames, buf = split_frames(buf)
        for topic, body in frames:
            if topic.endswith("/driver/heartbeat"):
                send("/user/ipc/custom/driver/heartbeat",
                     {"id": "hb", "time_stamp": str(int(time.time() * 1000))})
            elif topic.endswith("/thing/property/down"):
                log("[rx] %s %s" % (topic, body[:300]))
                handle_down(load_conf(), body)
            else:
                log("[rx-other] %s %s" % (topic, body[:200]))


if __name__ == "__main__":
    while True:
        try:
            main()
        except Exception as err:  # noqa: BLE001
            log("[main] 异常 %s" % err)
        with _lock:
            _sock = None
        time.sleep(2)
